#!/bin/sh
# Privileged install entry — invoked by ZapretKurulum.app
set -e
PAYLOAD="$(CDPATH= cd -- "$(dirname "$0")" && pwd)"
export ZAPRET_HOME="$PAYLOAD"
export ZAPRET_UPSTREAM="$PAYLOAD/bundled"
export CONFIG_SRC="$PAYLOAD/config/config.macos-hostlist"
export HOSTLIST_SRC="$PAYLOAD/config/zapret-hosts-user.txt"
export ZAPRET_CLEAN_REINSTALL=1
if [ -f "$PAYLOAD/VERSION" ]; then
	export ZAPRET_VERSION="$(tr -d ' \t\r\n' < "$PAYLOAD/VERSION")"
fi

# Resolve console user for sudoers (installer may run as root without SUDO_USER)
if [ -z "$SUDO_USER" ] || [ "$SUDO_USER" = "root" ]; then
	CU=$(stat -f '%Su' /dev/console 2>/dev/null || true)
	if [ -n "$CU" ] && [ "$CU" != "root" ]; then
		export SUDO_USER="$CU"
	fi
fi

"$PAYLOAD/scripts/system-install.sh"

# Install menubar app (prebuilt — no swiftc required on target)
APP_SRC="$PAYLOAD/menubar/ZapretToggle.app"
if [ -d "$APP_SRC" ]; then
	rm -rf /Applications/ZapretToggle.app
	cp -R "$APP_SRC" /Applications/
	xattr -dr com.apple.quarantine /Applications/ZapretToggle.app 2>/dev/null || true
	echo "Menubar: /Applications/ZapretToggle.app"
else
	echo "UYARI: ZapretToggle.app payload icinde yok"
fi

# Optional: launch menubar for the console user
CU="${SUDO_USER:-$(stat -f '%Su' /dev/console 2>/dev/null)}"
if [ -n "$CU" ] && [ "$CU" != "root" ]; then
	sudo -u "$CU" open /Applications/ZapretToggle.app 2>/dev/null || true
fi

echo "INSTALL_OK"
